package catHouse.entities.houses;

import catHouse.entities.cat.BaseCat;
import catHouse.entities.cat.Cat;
import catHouse.entities.toys.Toy;

import java.util.ArrayList;
import java.util.Collection;

public abstract class BaseHouse implements House{
    private String name;
    private int capacity;
    private Collection<Toy> toys;
    private Collection<Cat> cats;

    protected BaseHouse(String name, int capacity) {
        this.setName(name);
        this.setCapacity(capacity);
        this.toys = new ArrayList<>();
        this.cats = new ArrayList<>();
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    //    • name - String
    //        ◦ If the name is null or whitespace, throw a NullPointerException with a message:
    //"House name cannot be null or empty."
    //        ◦ All names are unique.
    //    • capacity -  int
    //        ◦ The number of Cat аn House can have.
    //    • toys - Collection<Toy>
    //    • cats - Collection<Cat>

    @Override
    public int sumSoftness() {
        return 0;
    }

    @Override
    public void addCat(Cat cat) {

    }

    @Override
    public void removeCat(Cat cat) {

    }

    @Override
    public void buyToy(Toy toy) {

    }

    @Override
    public void feeding() {

    }

    @Override
    public String getStatistics() {
        return null;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public Collection<Cat> getCats() {
        return cats;
    }

    @Override
    public Collection<Toy> getToys() {
        return toys;
    }
}
