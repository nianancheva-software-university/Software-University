package catHouse.entities.cat;

public abstract class BaseCat implements Cat{
    private String name;
    private String breed;
    private int kilograms;
    private double price;

    protected BaseCat(String name, String breed, double price) {
        this.setName(name);
        this.setBreed(breed);
        this.setPrice(price);
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void setKilograms(int kilograms) {
        this.kilograms = kilograms;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    //    • name - String
    //        ◦ If the name is null or whitespace, throw a NullPointerException with a message:
    //"Cat name cannot be null or empty."
    //        ◦ All names are unique.
    //    • breed -  String
    //        ◦ If the breed is null or whitespace, throw a NullPointerException with a message:
    //"Cat breed cannot be null or empty."
    //    • kilograms -  int
    //        ◦ The kilograms of the Cat.
    //    • price - double
    //        ◦ The price of the Cat.
    //        ◦ If the price is below or equal to 0, throw an IllegalArgumentException with a message:
    // "Cat price cannot be below or equal to 0."

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int getKilograms() {
        return kilograms;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void eating() {

    }
}
